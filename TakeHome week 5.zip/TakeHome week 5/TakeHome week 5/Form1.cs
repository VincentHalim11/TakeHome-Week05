﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization.Configuration;

namespace TakeHome_week_5
{
    public partial class Form1 : Form
    {
        DataTable simpen = new DataTable();
        DataTable tampil = new DataTable();
        DataTable kategori = new DataTable();
        string count = "5";
        int point = 5;
        string id = "";
        string id_karegori;
        string code;
        string filter_category;
        int terpilih;
        string hapus;
        bool lagi;
        Dictionary<string, int> counters = new Dictionary<string, int>();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tampil.Columns.Add("ID Product");
            tampil.Columns.Add("Nama Product");
            tampil.Columns.Add("Harga");
            tampil.Columns.Add("Stock");
            tampil.Columns.Add("ID Category");
            tampil.Rows.Add("J001","Jas Hitam","100000","10","C1");
            tampil.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            tampil.Rows.Add("T002", "T-Shirt Obsessive ", "75000", "16", "C2");
            tampil.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            tampil.Rows.Add("J002", "Jeans Biru", "90000", "5", "C1");
            tampil.Rows.Add("C002", "Celana Pendek Coklat", "60000", "11", "C4");
            tampil.Rows.Add("C002", "Cawat Blink - blink", "1000000", "1", "C5");
            tampil.Rows.Add("R001", "Rocca Shirt ","50000","8","C2");


            kategori.Columns.Add("ID Category");
            kategori.Columns.Add("Nama Category");
            kategori.Rows.Add("C1","Jas");
            kategori.Rows.Add("C2","T-Shirt");
            kategori.Rows.Add("C3","Rok");
            kategori.Rows.Add("C4","Celana");
            kategori.Rows.Add("C5","Cawat");


            cb_kategori.Items.Add("Jas");
            cb_kategori.Items.Add("T-Shirt");
            cb_kategori.Items.Add("Rok");
            cb_kategori.Items.Add("Celana");
            cb_kategori.Items.Add("Cawat");


            datagrid_tampil.DataSource = tampil;
            datagrid_kategori.DataSource = kategori;
            
            counters["R"] = 2;
            counters["T"] = 2;
            counters["J"] = 2;
            counters["C"] = 2;
        }

        //btn filter & all
        private void btn_all_Click(object sender, EventArgs e)
        {
            if (cb_filter.Enabled == true)
            {
                cb_filter.Enabled = false;
            }
         
            
            cb_filter.SelectedItem = null;
            simpen.Clear();
            simpen = tampil.Copy();
            datagrid_tampil.DataSource = simpen;
            datagrid_tampil.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            if (cb_filter.Enabled == false)
            {
                cb_filter.Enabled = true;
            }
        }

        //detail
        private void btn_add1_Click(object sender, EventArgs e)
        {
            if(txt_namadetail.Text=="")
            {
                MessageBox.Show("Harus diisi semua", "peringatan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string nama = txt_namadetail.Text;
                string cathegori = cb_kategori.Text;
                string harga = txt_harga.Text;
                string Stock = txt_stock.Text;
                string huruf = " ";
                string id = GenerateCode(txt_namadetail.Text);

                for (int i = 0; i < kategori.Rows.Count; i++)
                {
                    if (kategori.Rows[i][1].ToString().Contains(cb_kategori.Text))
                    {
                        code = kategori.Rows[i][0].ToString();
                    }
                }

                if (nama == "" || cathegori == "" || harga == "" || Stock == "")
                {
                    MessageBox.Show("Harus diisi semua", "peringatan", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    tampil.Rows.Add(id, nama, harga, Stock, code);
                }
            }
           

           
        }

        private void txt_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)
            {
                e.Handled = true;
            }

        }

        private void btn_remove1_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in datagrid_tampil.SelectedRows)
            {
                datagrid_tampil.Rows.Remove(row);
               
            }
        }

         private void datagrid_tampil_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string idjenis = datagrid_tampil.SelectedRows[0].Cells[4].Value.ToString();
            terpilih = e.RowIndex;

            foreach(DataRow barang in kategori.Rows)
            {
                if (barang["ID Category"].ToString() ==idjenis)
                {
                    id_karegori = barang["Nama Category"].ToString();
                    break;
                }
            }
            
            DataGridViewRow row = this.datagrid_tampil.Rows[e.RowIndex];

            txt_namadetail.Text = row.Cells[1].Value.ToString();
            txt_harga.Text = row.Cells[2].Value.ToString();
            txt_stock.Text = row.Cells[3].Value.ToString();
            cb_kategori.Text = id_karegori;

        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if(txt_namadetail.Text == ""||txt_harga.Text==""||txt_stock.Text==""||cb_kategori.Text=="")
            {
                MessageBox.Show("pilih dulu");
            }
            else
            {

                DataGridViewRow row = datagrid_tampil.Rows[terpilih];
                tampil.Rows[row.Index]["Nama Product"] = txt_namadetail.Text;
                tampil.Rows[row.Index]["Harga"] = txt_harga.Text;
                tampil.Rows[row.Index]["Stock"] = txt_stock.Text;
                tampil.Rows[row.Index]["ID Category"] = GetCategoryID(cb_kategori.Text);

                if (int.Parse(txt_stock.Text) == 0)
                {
                    datagrid_tampil.Rows.RemoveAt(datagrid_tampil.SelectedRows[0].Index);
                }
                datagrid_tampil.Refresh();

                txt_namadetail.Clear();
                txt_harga.Clear();
                txt_stock.Clear();
                
            }
            

        }

        //kategori
        private void btn_add2_Click(object sender, EventArgs e)
        {
            string barang = txt_produk.Text;
            bool cek = true;

            if (txt_produk.Text == "")
            {
                MessageBox.Show("masukkan isi", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cek = false;
            }
            else
            {
                for (int i = 0; i < kategori.Rows.Count; i++)
                {


                    if (kategori.Rows[i][1].ToString().Contains(txt_produk.Text))
                    {
                        MessageBox.Show("Barang sudah ada", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        cek = false;
                    }

                    else
                    {
                        string isi = kategori.Rows[i][0].ToString();
                        string angka = isi[1].ToString();
                        if (isi.Length > 0)
                        {
                            if (angka == count)
                            {
                                point++;
                            }
                        }
                    }
                }

                if (cek == true)
                {
                    
                    int a = Convert.ToInt32(count);
                    a = a + 1;
                    count = a.ToString();
                    string id = $"C{count}";
                    kategori.Rows.Add(id, barang);
                    cb_kategori.Items.Add(barang);
                    cb_filter.Items.Add(barang);
                    
                }
            }
 
        }

        private void btn_remove2_Click(object sender, EventArgs e)
        {

            hapus = datagrid_kategori.CurrentRow.Cells[0].Value.ToString();

            foreach (DataGridViewRow row in datagrid_kategori.SelectedRows)
            {
                datagrid_kategori.Rows.Remove(row);
            }

            
        }

        //filter
        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {

            simpen.Clear();

            if (!simpen.Columns.Contains("ID Product"))
            {
                simpen.Columns.Add("ID Product", typeof(string));
            }
            if (!simpen.Columns.Contains("Nama Product"))
            {
                simpen.Columns.Add("Nama Product", typeof(string));
            }
            if (!simpen.Columns.Contains("Harga"))
            {
                simpen.Columns.Add("Harga", typeof(string));
            }
            if (!simpen.Columns.Contains("Stock"))
            {
                simpen.Columns.Add("Stock", typeof(string));
            }
            if (!simpen.Columns.Contains("ID Category"))
            {
                simpen.Columns.Add("ID Category", typeof(string));
            }


            List<string> selectedCategories = new List<string>();
            if (cb_filter.SelectedItem != null && cb_filter.SelectedItem.ToString() != "All Categories")
            {
                selectedCategories.Add(cb_filter.SelectedItem.ToString());
            }

            if (selectedCategories.Count == 0)
            {
                simpen = tampil.Copy();
            }
            else
            {
                string categoryID = GetCategoryID(selectedCategories[0]);
                if (!string.IsNullOrEmpty(categoryID))
                {
                    foreach (DataRow row in simpen.Rows)
                    {
                        if (row["ID Category"].ToString() == categoryID)
                        {
                            simpen.Rows.Add(row["ID Product"].ToString(), row["Nama Product"].ToString(), row["Harga"].ToString(), row["Stock"].ToString(), row["ID Category"].ToString());
                        }
                    }
                }
            }

            datagrid_tampil.DataSource = simpen;
            datagrid_tampil.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


        }

        private string GetCategoryID(string categoryName)
        {
            foreach (DataRow row in kategori.Rows)
            {
                if (row["Nama Category"].ToString().Equals(categoryName))
                {
                    return row["ID Category"].ToString();
                }
            }
            return "";
        }


        private string GenerateCode(string itemName)
        {
            string firstLetter = itemName.Substring(0, 1).ToUpper();
            if (!counters.ContainsKey(firstLetter))
            {
                counters[firstLetter] = 1;
            }
            else
            {
                counters[firstLetter]++;
            }


            return firstLetter + counters[firstLetter].ToString("D3");
        }
    }
}
