﻿namespace TakeHome_week_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagrid_tampil = new System.Windows.Forms.DataGridView();
            this.datagrid_kategori = new System.Windows.Forms.DataGridView();
            this.lbl_produk = new System.Windows.Forms.Label();
            this.lbl_detail = new System.Windows.Forms.Label();
            this.lbl_kategori = new System.Windows.Forms.Label();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.lbl_namakategori = new System.Windows.Forms.Label();
            this.lbl_harga = new System.Windows.Forms.Label();
            this.lbl_kategoridetail = new System.Windows.Forms.Label();
            this.lbl_namadetail = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_namadetail = new System.Windows.Forms.TextBox();
            this.txt_stock = new System.Windows.Forms.TextBox();
            this.txt_harga = new System.Windows.Forms.TextBox();
            this.txt_produk = new System.Windows.Forms.TextBox();
            this.btn_remove1 = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_add1 = new System.Windows.Forms.Button();
            this.btn_add2 = new System.Windows.Forms.Button();
            this.btn_remove2 = new System.Windows.Forms.Button();
            this.cb_kategori = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_tampil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_kategori)).BeginInit();
            this.SuspendLayout();
            // 
            // datagrid_tampil
            // 
            this.datagrid_tampil.AllowUserToResizeColumns = false;
            this.datagrid_tampil.AllowUserToResizeRows = false;
            this.datagrid_tampil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid_tampil.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.datagrid_tampil.Location = new System.Drawing.Point(48, 68);
            this.datagrid_tampil.Name = "datagrid_tampil";
            this.datagrid_tampil.RowHeadersVisible = false;
            this.datagrid_tampil.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagrid_tampil.Size = new System.Drawing.Size(437, 209);
            this.datagrid_tampil.TabIndex = 0;
            this.datagrid_tampil.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagrid_tampil_CellClick);
            // 
            // datagrid_kategori
            // 
            this.datagrid_kategori.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid_kategori.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.datagrid_kategori.Location = new System.Drawing.Point(524, 68);
            this.datagrid_kategori.Name = "datagrid_kategori";
            this.datagrid_kategori.ReadOnly = true;
            this.datagrid_kategori.RowHeadersVisible = false;
            this.datagrid_kategori.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagrid_kategori.Size = new System.Drawing.Size(178, 180);
            this.datagrid_kategori.TabIndex = 1;
            // 
            // lbl_produk
            // 
            this.lbl_produk.AutoSize = true;
            this.lbl_produk.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_produk.Location = new System.Drawing.Point(44, 20);
            this.lbl_produk.Name = "lbl_produk";
            this.lbl_produk.Size = new System.Drawing.Size(82, 24);
            this.lbl_produk.TabIndex = 2;
            this.lbl_produk.Text = "Product";
            // 
            // lbl_detail
            // 
            this.lbl_detail.AutoSize = true;
            this.lbl_detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_detail.Location = new System.Drawing.Point(44, 290);
            this.lbl_detail.Name = "lbl_detail";
            this.lbl_detail.Size = new System.Drawing.Size(65, 20);
            this.lbl_detail.TabIndex = 3;
            this.lbl_detail.Text = "Details";
            // 
            // lbl_kategori
            // 
            this.lbl_kategori.AutoSize = true;
            this.lbl_kategori.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kategori.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_kategori.Location = new System.Drawing.Point(520, 20);
            this.lbl_kategori.Name = "lbl_kategori";
            this.lbl_kategori.Size = new System.Drawing.Size(93, 24);
            this.lbl_kategori.TabIndex = 4;
            this.lbl_kategori.Text = "Category";
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(298, 41);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(42, 21);
            this.btn_all.TabIndex = 5;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(346, 41);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(43, 21);
            this.btn_filter.TabIndex = 6;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Topi"});
            this.cb_filter.Location = new System.Drawing.Point(395, 41);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(90, 21);
            this.cb_filter.TabIndex = 7;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // lbl_namakategori
            // 
            this.lbl_namakategori.AutoSize = true;
            this.lbl_namakategori.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_namakategori.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_namakategori.Location = new System.Drawing.Point(521, 258);
            this.lbl_namakategori.Name = "lbl_namakategori";
            this.lbl_namakategori.Size = new System.Drawing.Size(50, 16);
            this.lbl_namakategori.TabIndex = 8;
            this.lbl_namakategori.Text = "Nama :";
            // 
            // lbl_harga
            // 
            this.lbl_harga.AutoSize = true;
            this.lbl_harga.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_harga.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_harga.Location = new System.Drawing.Point(59, 369);
            this.lbl_harga.Name = "lbl_harga";
            this.lbl_harga.Size = new System.Drawing.Size(47, 15);
            this.lbl_harga.TabIndex = 9;
            this.lbl_harga.Text = "Harga :";
            // 
            // lbl_kategoridetail
            // 
            this.lbl_kategoridetail.AutoSize = true;
            this.lbl_kategoridetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kategoridetail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_kategoridetail.Location = new System.Drawing.Point(45, 345);
            this.lbl_kategoridetail.Name = "lbl_kategoridetail";
            this.lbl_kategoridetail.Size = new System.Drawing.Size(61, 15);
            this.lbl_kategoridetail.TabIndex = 10;
            this.lbl_kategoridetail.Text = "Category :";
            // 
            // lbl_namadetail
            // 
            this.lbl_namadetail.AutoSize = true;
            this.lbl_namadetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_namadetail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_namadetail.Location = new System.Drawing.Point(59, 317);
            this.lbl_namadetail.Name = "lbl_namadetail";
            this.lbl_namadetail.Size = new System.Drawing.Size(47, 15);
            this.lbl_namadetail.TabIndex = 11;
            this.lbl_namadetail.Text = "Nama :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Location = new System.Drawing.Point(59, 401);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "Stock :";
            // 
            // txt_namadetail
            // 
            this.txt_namadetail.Location = new System.Drawing.Point(112, 312);
            this.txt_namadetail.Name = "txt_namadetail";
            this.txt_namadetail.Size = new System.Drawing.Size(373, 20);
            this.txt_namadetail.TabIndex = 13;
            // 
            // txt_stock
            // 
            this.txt_stock.Location = new System.Drawing.Point(112, 400);
            this.txt_stock.Name = "txt_stock";
            this.txt_stock.Size = new System.Drawing.Size(156, 20);
            this.txt_stock.TabIndex = 14;
            this.txt_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_harga_KeyPress);
            // 
            // txt_harga
            // 
            this.txt_harga.Location = new System.Drawing.Point(112, 369);
            this.txt_harga.Name = "txt_harga";
            this.txt_harga.Size = new System.Drawing.Size(156, 20);
            this.txt_harga.TabIndex = 16;
            this.txt_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_harga_KeyPress);
            // 
            // txt_produk
            // 
            this.txt_produk.Location = new System.Drawing.Point(577, 257);
            this.txt_produk.Name = "txt_produk";
            this.txt_produk.Size = new System.Drawing.Size(125, 20);
            this.txt_produk.TabIndex = 17;
            // 
            // btn_remove1
            // 
            this.btn_remove1.Location = new System.Drawing.Point(429, 382);
            this.btn_remove1.Name = "btn_remove1";
            this.btn_remove1.Size = new System.Drawing.Size(56, 38);
            this.btn_remove1.TabIndex = 18;
            this.btn_remove1.Text = "Remove Product";
            this.btn_remove1.UseVisualStyleBackColor = true;
            this.btn_remove1.Click += new System.EventHandler(this.btn_remove1_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.Location = new System.Drawing.Point(361, 382);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(62, 38);
            this.btn_edit.TabIndex = 19;
            this.btn_edit.Text = "Edit Product";
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_add1
            // 
            this.btn_add1.Location = new System.Drawing.Point(298, 382);
            this.btn_add1.Name = "btn_add1";
            this.btn_add1.Size = new System.Drawing.Size(57, 38);
            this.btn_add1.TabIndex = 20;
            this.btn_add1.Text = "Add Product";
            this.btn_add1.UseVisualStyleBackColor = true;
            this.btn_add1.Click += new System.EventHandler(this.btn_add1_Click);
            // 
            // btn_add2
            // 
            this.btn_add2.Location = new System.Drawing.Point(586, 290);
            this.btn_add2.Name = "btn_add2";
            this.btn_add2.Size = new System.Drawing.Size(57, 38);
            this.btn_add2.TabIndex = 21;
            this.btn_add2.Text = "Add Category";
            this.btn_add2.UseVisualStyleBackColor = true;
            this.btn_add2.Click += new System.EventHandler(this.btn_add2_Click);
            // 
            // btn_remove2
            // 
            this.btn_remove2.Location = new System.Drawing.Point(646, 290);
            this.btn_remove2.Name = "btn_remove2";
            this.btn_remove2.Size = new System.Drawing.Size(56, 38);
            this.btn_remove2.TabIndex = 22;
            this.btn_remove2.Text = "Remove Category";
            this.btn_remove2.UseVisualStyleBackColor = true;
            this.btn_remove2.Click += new System.EventHandler(this.btn_remove2_Click);
            // 
            // cb_kategori
            // 
            this.cb_kategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_kategori.FormattingEnabled = true;
            this.cb_kategori.Location = new System.Drawing.Point(112, 342);
            this.cb_kategori.Name = "cb_kategori";
            this.cb_kategori.Size = new System.Drawing.Size(156, 21);
            this.cb_kategori.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 450);
            this.Controls.Add(this.cb_kategori);
            this.Controls.Add(this.btn_remove2);
            this.Controls.Add(this.btn_add2);
            this.Controls.Add(this.btn_add1);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.btn_remove1);
            this.Controls.Add(this.txt_produk);
            this.Controls.Add(this.txt_harga);
            this.Controls.Add(this.txt_stock);
            this.Controls.Add(this.txt_namadetail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_namadetail);
            this.Controls.Add(this.lbl_kategoridetail);
            this.Controls.Add(this.lbl_harga);
            this.Controls.Add(this.lbl_namakategori);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.lbl_kategori);
            this.Controls.Add(this.lbl_detail);
            this.Controls.Add(this.lbl_produk);
            this.Controls.Add(this.datagrid_kategori);
            this.Controls.Add(this.datagrid_tampil);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_tampil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_kategori)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView datagrid_tampil;
        private System.Windows.Forms.DataGridView datagrid_kategori;
        private System.Windows.Forms.Label lbl_produk;
        private System.Windows.Forms.Label lbl_detail;
        private System.Windows.Forms.Label lbl_kategori;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Label lbl_namakategori;
        private System.Windows.Forms.Label lbl_harga;
        private System.Windows.Forms.Label lbl_kategoridetail;
        private System.Windows.Forms.Label lbl_namadetail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_namadetail;
        private System.Windows.Forms.TextBox txt_stock;
        private System.Windows.Forms.TextBox txt_harga;
        private System.Windows.Forms.TextBox txt_produk;
        private System.Windows.Forms.Button btn_remove1;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_add1;
        private System.Windows.Forms.Button btn_add2;
        private System.Windows.Forms.Button btn_remove2;
        private System.Windows.Forms.ComboBox cb_kategori;
    }
}

